/*----------------------------------------------------------------------------/
/  IR_CTRL - IR remote control module  R0.02                  (C)ChaN, 2015
/-----------------------------------------------------------------------------/
/ The IR_CTRL is a generic Transmisson/Reception control module for IR remote
/ control systems. This is a free software and is opened for education,
/ research and development under license policy of following trems.
/
/  Copyright (C) 2015, ChaN, all right reserved.
/
/ * The IR_CTRL module is a free software and there is no warranty.
/ * You can use, modify and/or redistribute it for personal, non-profit or
/   commercial use without restriction under your responsibility.
/ * Redistributions of source code must retain the above copyright notice.
/
/-----------------------------------------------------------------------------/
/ Aug 30,'08 R0.01  First release.
/ Jul 18,'15 R0.02  Added timing compensation, Improved RAM consumption.
/----------------------------------------------------------------------------*/
#include "mcc_generated_files/mcc.h"
#include "ir_ctrl.h"



/*----------------------------------------------------------------------------/
/ Platform dependent definitions
/ (Macros not needed in this configuration should be left blanked)
/----------------------------------------------------------------------------*/

/* Definitions of hardware control macros */
#ifdef _16F1705
/* TMR1 16bit timer 1us */
#define	INIT_TMR()	{T1CONbits.TMR1ON=0;TMR1_WriteTimer(0u);T1CONbits.TMR1ON =1;PIE1bits.TMR1IE = 1;}				/* Always: Initialize Timers, Ports */

#define	INIT_XMIT()	{}				/* TX: Initialize IR transmitter */
#define IRTX_38K()	{NCO1CONbits.N1EN = 0;NCO1INCH = 0x9B; NCO1INCL = 0xA6; NCO1CONbits.N1EN = 1;}				/* TX && NEC/AEHA: Set IR sub-carrier to 38kHz */
#define IRTX_40K()	{NCO1CONbits.N1EN = 0;NCO1INCH = 0xA3; NCO1INCL = 0xD7; NCO1CONbits.N1EN = 1;}				/* TX && SONY: Set IR sub-carrier to 40kHz */
#define IRTX_ON()   DSM_ManualModulationSet()		 	/* TX: IR sub-carrier on */
#define IRTX_OFF()  DSM_ManualModulationClear()		/* TX: IR sub-carrier off */
#define IRTX_TST()  (MDCONbits.MDBIT == 1)			/* TX: Check status of IR sub-carrier (true:on) */

/* CCP2: Capture mode(TMR1) */
#define CAPT_FALLING_EDGE() CCP2CON=0x04   /* Falling edge */
#define CAPT_RISING_EDGE()  CCP2CON=0x05      /* Rising edge */
#define CAPT_STA()	{CAPT_FALLING_EDGE();}				/* RX: Set capture on IR start (left blanked if it can capture on both edge) */
#define CAPT_STP()	{CAPT_RISING_EDGE();}				/* RX: Set capture on IR stop (left blanked if it can capture on both edge) */
#define CAPT_TST()	!IR_RCV_GetValue()				/* RX: Check which edge triggered the capture event (true:IR start) */
#define	CAPT_VAL()	(CCPR2) //CCPR2(16bit REG) // capturedValue(isr param1: uint16_t)	/* RX: Get the captured timer value */
#define CAPT_ENA()	{CAPT_FALLING_EDGE();PIE2bits.CCP2IE = 1;}					/* RX: Enable capture interrupt */
#define CAPT_DIS()	{PIE2bits.CCP2IE = 0;}				/* RX && TX: Disable capture interrupt */

/* CCP1: Compare mode(TMR1) */
#define COMP_ENA(n)		{CCP1_SetCompareCount(TMR1_ReadTimer() + n);PIE1bits.CCP1IE = 1;}			/* Always: Enable compare interrupt n count after now */
#define COMP_DIS()		{PIE1bits.CCP1IE = 0;} 	/* Always: Disable compare interrupt */
#define COMP_NXT(n)		{CCP1_SetCompareCount(CCPR1+n);}			/* TX: Increase compare register by n count */
#endif

#ifdef _16F18446
/* Definitions of hardware control macros */
/* TMR1 16bit timer 1us */
#define	INIT_TMR()	{T1CONbits.TMR1ON=0;TMR1_WriteTimer(0u);T1CONbits.TMR1ON =1;PIE4bits.TMR1IE = 1;}				/* Always: Initialize Timers, Ports */

#define	INIT_XMIT()	{}				/* TX: Initialize IR transmitter */
#define IRTX_38K()	{NCO1CONbits.N1EN = 0;NCO1INCH = 0x9B; NCO1INCL = 0xA6; NCO1CONbits.N1EN = 1;}				/* TX && NEC/AEHA: Set IR sub-carrier to 38kHz */
#define IRTX_40K()	{NCO1CONbits.N1EN = 0;NCO1INCH = 0xA3; NCO1INCL = 0xD7; NCO1CONbits.N1EN = 1;}				/* TX && SONY: Set IR sub-carrier to 40kHz */
#define IRTX_ON()   DSM_ManualModulationSet()		 	/* TX: IR sub-carrier on */
#define IRTX_OFF()  DSM_ManualModulationClear()		/* TX: IR sub-carrier off */
#define IRTX_TST()  (MDCONbits.MDBIT == 1)			/* TX: Check status of IR sub-carrier (true:on) */

/* CCP2: Capture mode(TMR1) */
#define CAPT_BOTH_EDGE() CCP2CON=0x83   /* Both edge */
#define CAPT_FALLING_EDGE() CCP2CON=0x84   /* Falling edge */
#define CAPT_RISING_EDGE() CCP2CON=0x85      /* Rising edge */
#define CAPT_STA()	{CAPT_FALLING_EDGE();}				/* RX: Set capture on IR start (left blanked if it can capture on both edge) */
#define CAPT_STP()	{CAPT_RISING_EDGE();}				/* RX: Set capture on IR stop (left blanked if it can capture on both edge) */
#define CAPT_TST()	!IR_IN_GetValue()				/* RX: Check which edge triggered the capture event (true:IR start) */
#define	CAPT_VAL()	CCPR2 //CCPR2 // capturedValue				/* RX: Get the captured timer value */
#define CAPT_ENA()	{CAPT_FALLING_EDGE();CCP2CONbits.CCP2EN=1;PIE6bits.CCP2IE = 1;}					/* RX: Enable capture interrupt */
#define CAPT_DIS()	{CCP2CONbits.CCP2EN=0;PIE6bits.CCP2IE = 0;}				/* RX && TX: Disable capture interrupt */

/* CCP1: Compare mode(TMR1) */
#define COMP_ENA(n)		{CCP1CONbits.CCP1EN=0;CCP1_SetCompareCount(TMR1_ReadTimer() + n);CCP1CONbits.CCP1EN=1;PIE6bits.CCP1IE = 1;}			/* Always: Enable compare interrupt n count after now */
#define COMP_DIS()		{CCP1CONbits.CCP1EN=0;PIE6bits.CCP1IE = 0;}     /* Always: Disable compare interrupt */
#define COMP_NXT(n)		{CCP1CONbits.CCP1EN=0;CCP1_SetCompareCount(CCPR1+n);CCP1CONbits.CCP1EN=1;}			/* TX: Increase compare register by n count */
#endif
/* Counter clock rate and register width */
#define T_CLK	(1000)					/* Always: Timer tick period [ns] */
#define	irtmr_t	uint16_t					/* Always: Integer type of timer counter */

/* Definitions of interrupt service functions */
#define	ISR_COMPARE()	void isr_compare(void)			/* Always: Timer compare match ISR */
#define	ISR_CAPTURE()	void isr_capture(uint16_t capturedValue)			/* RX: Timer input capture ISR */
#define CALLBACK_TX()	 			/* TX: Callback function on end of transmission */
#define CALLBACK_RX()				/* RX: Callback function on frame arrival */


/*---------------------------------------------------------------------------*/


/* IR control timings */
#define	T_NEC	(562000/T_CLK)		/* Base time for NEC format (T=562us) */
#define	T_AEHA	(425000/T_CLK)		/* Base time for AEHA format (T=425us) */
#define T_SONY	(600000/T_CLK)		/* Base time for SONY format (T=600us) */
#define T_TRAIL	(6000000u/T_CLK)		/* Trailer detection time (6ms) */

#define MUL16(n)    (n << 4)    /* n*16 */
#define MUL8(n)     (n << 3)    /* n*8 */
#define MUL4(n)     (n << 2)    /* n*4 */
#define MUL2(n)     (n << 1)    /* n*2 */
#define MUL2_5(n)     ((n << 1) + (n >> 1))    /* n*2.5 */
#define MUL1_5(n)     ((n) + (n >> 1))    /* n*1.5 */
#define MUL1_25(n)     ((n) + (n >> 2))    /* n*1.25 */
#define MUL0_75(n)     ((n) - (n >> 2))    /* n*0.75 */

#define DIV16(n)    (n >> 4)    /* n/16 */
#define DIV8(n)     (n >> 3)    /* n/8 */
#define DIV4(n)     (n >> 2)    /* n/4 */
#define DIV2(n)     (n >> 1)    /* n/2 */

#define L_WINDOW(pw,t)	(pw >= MUL0_75(t) && pw <= MUL1_25(t))
// #define L_WINDOW(pw,t)	(pw >= (uint16_t)(0.75 * t) && pw <= (uint16_t)(1.33 * t))

/* Using only a format */
#if IR_USE_NEC && !IR_USE_AEHA && !IR_USE_SONY
#define USE_NEC_ONLY	1
#else
#define USE_NEC_ONLY	0
#endif
#if !IR_USE_NEC && IR_USE_AEHA && !IR_USE_SONY
#define USE_AEHA_ONLY	1
#else
#define USE_AEHA_ONLY	0
#endif
#if !IR_USE_NEC && !IR_USE_AEHA && IR_USE_SONY
#define USE_SONY_ONLY	1
#else
#define USE_SONY_ONLY	0
#endif


/* Working area for IR communication  */

volatile IR_STRUCT IrCtrl;


/*----------------------------------------------------*/
/* Timer capture ISR                                  */
/* (IR receiving interrupt on either edge of input)   */
/*----------------------------------------------------*/

#if IR_USE_RCVR

ISR_CAPTURE() {
    static irtmr_t pw1, pw2, pth; /* Pulse width values */
    static uint8_t bm; /* Bit mask */
    irtmr_t pw, ct = CAPT_VAL();
    uint8_t i, f, d;


    if (!(CAPT_TST())) {
        /* Captured on stop of IR sub-carrier */
        CAPT_STA(); /* Next capture event is start of IR */
        COMP_ENA(T_TRAIL); /* Enable copmpare interrupt (trailer timer) */
        pw1 = ct - pw1; /* pw1: this mark length */
        pw2 = ct; /* pw2: current ct */
#if IR_USE_SONY
        //        if (IrCtrl.fmt == SONY && IrCtrl.stat == IR_RECVING && pw1 <= (uint16_t) (T_SONY * 2.5)) {
        if (IrCtrl.fmt == SONY && IrCtrl.stat == IR_RECVING && pw1 <= MUL2_5(T_SONY)) {
            i = IrCtrl.bc;
            if (i >= IR_MAX_RCVR) return;
            //i /= 8;
            i >>= 3;
            d = IrCtrl.rxdata[i] & ~bm;
            if (pw1 >= pth) d |= bm;
            IrCtrl.rxdata[i] = d;
            if ((bm <<= 1) == 0) bm = 1;
            IrCtrl.bc++;
        }
#endif
        return;
    }

    /* Captured on start of IR sub-carrier */
    CAPT_STP(); /* Next capture event is stop of IR */
    COMP_DIS(); /* Disable compare interrupt (trailer timer) */
    pw = pw1;
    pw1 = ct;
    ct -= pw2; /* pw: previous mark length, ct: this space length */
    if (IrCtrl.stat >= IR_RECVED) return; /* Reject if not ready to receive */

    /* Detection of leader pattern */
    f = 0;
#if IR_USE_NEC
    if (L_WINDOW(pw, MUL16(T_NEC))) { /* Test for NEC leader pattern */
        pth = DIV8(pw);
        if (L_WINDOW(ct, MUL8(T_NEC))) f = NEC;
        if (L_WINDOW(ct, MUL4(T_NEC))) f = NEC | REPT;
    }
#endif
#if IR_USE_AEHA
    if (L_WINDOW(pw, MUL8(T_AEHA))) { /* Test for AEHA leader pattern */
        pth = DIV4(pw);
        if (L_WINDOW(ct, MUL4(T_AEHA))) f = AEHA;
        if (L_WINDOW(ct, MUL8(T_AEHA))) f = AEHA | REPT;
    }
#endif
#if IR_USE_SONY
    if (L_WINDOW(pw, MUL4(T_SONY))) { /* Test for SONY leader pattern */
        //pth = pw * 3 / 8;
        pth = DIV8(pw + pw + pw);
        if (L_WINDOW(ct, T_SONY * 1)) f = SONY;
    }
#endif
    if (f) { /* A leader pattern is detected */
        IrCtrl.fmt = f;
        IrCtrl.bc = 0;
        bm = 1;
        IrCtrl.stat = IR_RECVING;
        return;
    }

    if (IrCtrl.stat == IR_RECVING) {
        f = IrCtrl.fmt;
#if IR_USE_SONY
        //        if (IR_USE_SONY && f == SONY && ct <= (uint16_t) (T_SONY * 1.5)) /* Is SONY data mark? */
        if (f == SONY && ct <= MUL1_5(T_SONY)) /* Is SONY data mark? */
            return;
#endif
        i = IrCtrl.bc;
        if (i >= IR_MAX_RCVR) return;
        // i /= 8;
        i >>= 3;
        d = IrCtrl.rxdata[i] & ~bm;
#if IR_USE_NEC
        //        if (IR_USE_NEC && f == NEC && pw <= (uint16_t) (T_NEC * 1.5) && ct <= (uint16_t) (T_NEC * 4.0)) { /* Is NEC data mark? */
        if (f == NEC && pw <= MUL1_5(T_NEC) && ct <= MUL4(T_NEC)) { /* Is NEC data mark? */
            if (ct >= pth) d |= bm;
            IrCtrl.rxdata[i] = d;
            if ((bm <<= 1) == 0) bm = 1;
            IrCtrl.bc++;
            return;
        }
#endif
#if IR_USE_AEHA
        //        if (IR_USE_AEHA && f == AEHA && pw <= (uint16_t) (T_AEHA * 1.5) && ct <= (uint16_t) (T_AEHA * 4.0)) { /* Is AEHA data mark? */
        if (f == AEHA && pw <= MUL1_5(T_AEHA) && ct <= MUL4(T_AEHA)) { /* Is AEHA data mark? */
            if (ct >= pth) d |= bm;
            IrCtrl.rxdata[i] = d;
            if ((bm <<= 1) == 0) bm = 1;
            IrCtrl.bc++;
            return;
        }
#endif
    }

    IrCtrl.stat = IR_IDLE; /* When an invalid mark width is detected, abort and return idle state */
    IrCtrl.fmt = 0;
}
#endif /* IR_USE_RCVR */


/*----------------------------------------------------*/
/* Timer compare-match ISR                            */
/* (Transmission timing and Trailer detection)        */

/*----------------------------------------------------*/

ISR_COMPARE() {
    uint8_t st = IrCtrl.stat;
#if IR_USE_XMIT
    uint8_t i, d, fmt = IrCtrl.fmt;
    uint16_t w = 0;

    if (st == IR_XMITING) {
        if (IRTX_TST()) { /* Is sub-carrier on transmission? */
            IRTX_OFF(); /* End of IR sub-carrier */
            i = IrCtrl.bc;
            if (i < IrCtrl.len) { /* Is there a bit to be sent? */
                if (USE_SONY_ONLY || (IR_USE_SONY && (fmt & SONY))) {
                    w = T_SONY;
                } else {
                    d = IrCtrl.txptr[i / 8] & 1 << (i % 8);
                    if (USE_AEHA_ONLY || (IR_USE_AEHA && (fmt & AEHA)))
                        w = d ? T_AEHA * 3 : T_AEHA;
                    if (USE_NEC_ONLY || (IR_USE_NEC && (fmt & NEC)))
                        w = d ? T_NEC * 3 : T_NEC;
                }
                COMP_NXT(w); /* Set space width */
                return;
            }
        } else {
            IRTX_ON(); /* Start of IR sub-carrier */
            i = ++IrCtrl.bc;
            if (USE_SONY_ONLY || (IR_USE_SONY && (fmt & SONY))) {
                w = (IrCtrl.txptr[i / 8] & 1 << (i % 8)) ? T_SONY * 2 : T_SONY;
            } else {
                if (USE_AEHA_ONLY || (IR_USE_AEHA && (fmt & AEHA)))
                    w = T_AEHA;
                if (USE_NEC_ONLY || (IR_USE_NEC && (fmt & NEC)))
                    w = T_NEC;
            }
            COMP_NXT(w); /* Set mark width */
            return;
        }
    }

    if (st == IR_XMIT) { /* End of AGC burst? */
        IRTX_OFF(); /* Stop carrier */
#if USE_NEC_ONLY
        w = IrCtrl.len ? T_NEC * 8 : T_NEC * 4; /* Data frame or Repeat frame? */
#elif USE_AEHA_ONLY
        w = IrCtrl.len ? T_AEHA * 4 : T_AEHA * 8; /* Data frame or Repeat frame? */
#elif USE_SONY_ONLY
        w = T_SONY;
#else
        switch (fmt) { /* Set next transition time */
#if IR_USE_SONY
            case SONY:
                w = T_SONY;
                break;
#endif
#if IR_USE_AEHA
            case AEHA:
                w = IrCtrl.len ? T_AEHA * 4 : T_AEHA * 8; /* Data frame or Repeat frame? */
                break;
#endif
#if IR_USE_NEC
            case NEC:
                w = IrCtrl.len ? T_NEC * 8 : T_NEC * 4; /* Data frame or Repeat frame? */
                break;
#endif
        }
#endif
        COMP_NXT(w);
        IrCtrl.stat = IR_XMITING;
        IrCtrl.bc = 0xFF;
        return;
    }
#endif /* IR_USE_XMIT */

    COMP_DIS(); /* Disable compare interrupt */

#if IR_USE_RCVR
    CAPT_STA(); /* Re-enable receiving */
    CAPT_ENA();
    if (st == IR_RECVING) { /* Trailer detected */
        IrCtrl.len = IrCtrl.bc;
        IrCtrl.stat = IR_RECVED;
        CALLBACK_RX();
        return;
    }
#endif

    IrCtrl.stat = IR_IDLE;
    IrCtrl.fmt = 0;
    CALLBACK_TX();
}




/*---------------------------*/
/* Data Transmission Request */
/*---------------------------*/

#if IR_USE_XMIT

int IR_xmit(
        uint8_t fmt, /* Frame format: NEC, AEHA or SONY */
        const void* data, /* Pointer to the data to be sent */
        uint8_t len /* Data length [bit]. 0 for a repeat frame */
        ) {
    irtmr_t lw;


    if (IrCtrl.stat != IR_IDLE) return 0; /* Abort when collision detected */

    switch (fmt) {
#if IR_USE_NEC
        case NEC:
            lw = T_NEC * 16; /* AGC burst length */
            IRTX_38K();
            break;
#endif
#if IR_USE_AEHA
        case AEHA:
            lw = T_AEHA * 8; /* AGC burst length */
            IRTX_38K();
            break;
#endif
#if IR_USE_SONY
        case SONY:
            lw = T_SONY * 4; /* AGC burst length */
            IRTX_40K();
            break;
#endif
        default:
            return 0;
    }

    CAPT_DIS();
    COMP_DIS();
    IrCtrl.fmt = fmt;
    IrCtrl.len = (USE_SONY_ONLY || (IR_USE_SONY && (fmt == SONY))) ? len - 1 : len;
    IrCtrl.txptr = (const uint8_t*) data;

    /* Start transmission sequense */
    IrCtrl.stat = IR_XMIT;
    IRTX_ON();
    COMP_ENA(lw);

    return 1;
}
#endif /* IR_USE_XMIT */



/*---------------------------*/
/* Initialize IR functions   */

/*---------------------------*/

void IR_initialize(void) {
    /* Initialize timer and port functions for IR communication */
    INIT_TMR();
    INIT_XMIT();

    IrCtrl.stat = IR_IDLE;
    IrCtrl.fmt = 0;

    /* Enable receiving */
    CAPT_STA();
    CAPT_ENA();
}
