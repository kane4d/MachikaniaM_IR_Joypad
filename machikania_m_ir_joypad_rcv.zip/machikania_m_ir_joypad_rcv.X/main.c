/**
  Generated Main Source File

  Company:
    Microchip Technology Inc.

  File Name:
    main.c

  Summary:
    This is the main file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  Description:
    This header file provides implementations for driver APIs for all modules selected in the GUI.
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.65.2
        Device            :  PIC16F1705
        Driver Version    :  2.00
 */

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
 */

#include "mcc_generated_files/mcc.h"
#include "ir_ctrl.h"

#define MAX_IDLE_COUNT (100)
#define SET_ALL_KEYUP() {\
                            k_up_SetHigh();\
                            k_down_SetHigh();\
                            k_left_SetHigh();\
                            k_right_SetHigh();\
                            k_fire_SetHigh();\
                            k_start_SetHigh();\
                        }

/* 
 * APPLE REMOTE (Old type White)
 *  $EE $87 $xx $17
 * https://en.wikipedia.org/wiki/Apple_Remote
 */
enum {
    AR_UP = 0x0b, // $05
    AR_DOWN = 0x0d, // $06
    AR_LEFT = 0x08, // $04
    AR_RIGHT = 0x07, // $03
    AR_CENTER = 0x4, // $02/start
    AR_MENU = 0x02, // $01/fire
    AR_XXX = 0xff, // keyup
} apple_remote_code;
#define IS_APPLE_REMOTE() (IrCtrl.rxdata[0] == 0xee && IrCtrl.rxdata[1] == 0x87 && IrCtrl.rxdata[3] == 0x17)

/*
 * SONY BD
 *  $xx $2d $0f
 * SONY TV: Vol Up, Vol Down
 *  $xx $20
 */
enum {
    SONYBD_UP = 0x39, // 
    SONYBD_DOWN = 0x3a, // 
    SONYBD_LEFT = 0x3b, // 
    SONYBD_RIGHT = 0x3c, // 
    SONYBD_CENTER = 0x3d, // start
    SONYBD_CH_UP = 0x10, // start
    SONYBD_CH_DOWN = 0x11, // fire
    SONYTV_VOL_UP = 0x92, // start
    SONYTV_VOL_DOWN = 0x93, // fire
    SONYBD_XXX = 0xff, // keyup
} sony_bd_code;
#define IS_SONY_BD() (IrCtrl.rxdata[1] == 0x2d && IrCtrl.rxdata[2] == 0x0f)
#define IS_SONY_TV() (IrCtrl.rxdata[1] == 0x20)

typedef enum {
    RT_NONE,
    APPLE_REMOTE,
    SONY_BD,
    YOUR_REMOCON,
} REMOCON_TYPE;

uint8_t setKeyDown(uint8_t keyCode, REMOCON_TYPE rType) {
    uint8_t lastKey = keyCode;
    SET_ALL_KEYUP();
    switch (rType) {
        case APPLE_REMOTE:
            switch (lastKey) {
                case AR_UP:
                    k_up_SetLow();
                    break;
                case AR_DOWN:
                    k_down_SetLow();
                    break;
                case AR_RIGHT:
                    k_right_SetLow();
                    break;
                case AR_LEFT:
                    k_left_SetLow();
                    break;
                case AR_MENU:
                    k_fire_SetLow();
                    break;
                case AR_CENTER:
                    k_start_SetLow();
                    break;
                default:
                    lastKey = AR_XXX;
            }
    __delay_ms(15);

            break;
        case SONY_BD:
            switch (lastKey) {
                case SONYBD_UP:
                    k_up_SetLow();
                    break;
                case SONYBD_DOWN:
                    k_down_SetLow();
                    break;
                case SONYBD_RIGHT:
                    k_right_SetLow();
                    break;
                case SONYBD_LEFT:
                    k_left_SetLow();
                    break;
                case SONYBD_CENTER:
                    k_start_SetLow();
                    break;
                case SONYBD_CH_UP:
                    k_start_SetLow();
                    break;
                case SONYBD_CH_DOWN:
                    k_fire_SetLow();
                    break;
                case SONYTV_VOL_UP:
                    k_start_SetLow();
                    break;
                case SONYTV_VOL_DOWN:
                    k_fire_SetLow();
                    break;
                default:
                    lastKey = SONYBD_XXX;
            }
    __delay_ms(5);
            break;
        case YOUR_REMOCON:
            // Your code
            break;
    }
    //SET_ALL_KEYUP();
    return lastKey;
}

/*
                         Main application
 */
void main(void) {

    /**
 ODx registers
     */
    ODCONA = 0x30;
    ODCONC = 0x3A;

    // initialize the device
    SYSTEM_Initialize();

    // When using interrupts, you need to set the Global and Peripheral Interrupt Enable bits
    // Use the following macros to:

    // Enable the Global Interrupts
    INTERRUPT_GlobalInterruptEnable();

    // Enable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptEnable();

    // Disable the Global Interrupts
    //INTERRUPT_GlobalInterruptDisable();

    // Disable the Peripheral Interrupts
    //INTERRUPT_PeripheralInterruptDisable();
    SET_ALL_KEYUP();
    IR_initialize();
    INTERRUPT_PeripheralInterruptEnable();

#if 0
    uint8_t IrStat, LastIrStat = IR_IDLE + 8;
    while (1) {
        //printf("IR monitor\n");
        // Add your application code

        IrStat = IrCtrl.stat;
        switch (IrStat) {
            case IR_IDLE:
                if (LastIrStat != IrStat)
                    printf("IDLE.");
                break;
            case IR_RECVING:
                //if ( LastIrStat != IrStat )
                //printf(".");
                // printf("%d",IrCtrl.fmt);
                // printf(", Irctr)
                break;
            case IR_RECVED:
                printf("Received\r\n");
                printf("fmt: %d\r\n", IrCtrl.fmt);
                printf("len: %d\r\n", IrCtrl.len);
                if (IrCtrl.fmt == NEC && IrCtrl.len >= 32) {
                    printf("N 0x%02X 0x%02X 0x%02X 0x%02X\r\n", IrCtrl.rxdata[0], IrCtrl.rxdata[1], IrCtrl.rxdata[2], IrCtrl.rxdata[3]);
                }
                if (IrCtrl.len == 0 && IrCtrl.fmt == (REPT | NEC)) {
                    printf("N Repeat\r\n");
                }
                if (IrCtrl.fmt == SONY) {
                    if (IrCtrl.len >= 20)
                        printf("S 0x%02X 0x%02X 0x%02X\r\n", IrCtrl.rxdata[0], IrCtrl.rxdata[1], IrCtrl.rxdata[2]);
                    else if (IrCtrl.len >= 15)
                        printf("S 0x%02X 0x%02X\r\n", IrCtrl.rxdata[0], IrCtrl.rxdata[1]);
                    else if (IrCtrl.len >= 12)
                        printf("S 0x%02X 0x%02X\r\n", IrCtrl.rxdata[0], IrCtrl.rxdata[1]);
                }
                if (IrCtrl.fmt == AEHA) {
                    if (IrCtrl.len >= 48)
                        printf("A 0x%02X 0x%02X 0x%02X 0x%02X 0x%02X 0x%02X\r\n", IrCtrl.rxdata[0], IrCtrl.rxdata[1], IrCtrl.rxdata[2], IrCtrl.rxdata[3], IrCtrl.rxdata[4], IrCtrl.rxdata[5]);
                    else if (IrCtrl.len >= 40)
                        printf("A 0x%02X 0x%02X 0x%02X 0x%02X 0x%02X\r\n", IrCtrl.rxdata[0], IrCtrl.rxdata[1], IrCtrl.rxdata[2], IrCtrl.rxdata[3], IrCtrl.rxdata[4]);
                    else if (IrCtrl.len >= 32)
                        printf("A 0x%02X 0x%02X 0x%02X 0x%02X\r\n", IrCtrl.rxdata[0], IrCtrl.rxdata[1], IrCtrl.rxdata[2], IrCtrl.rxdata[3]);
                    else if (IrCtrl.len >= 24)
                        printf("A 0x%02X 0x%02X 0x%02X\r\n", IrCtrl.rxdata[0], IrCtrl.rxdata[1], IrCtrl.rxdata[2]);
                }
                IrCtrl.stat = IR_IDLE;
                break;
        }
        LastIrStat = IrStat;

    }
#endif

    // Add your application code
    uint8_t IrStat, lastKey = AR_XXX, idleCount = 0;
    REMOCON_TYPE lastRemoconType = RT_NONE;
    while (1) {
        //printf("IR monitor\n");
        // Add your application code

        IrStat = IrCtrl.stat;
        switch (IrStat) {
            case IR_IDLE:
                if (idleCount++ > MAX_IDLE_COUNT) {
                    SET_ALL_KEYUP();
                    lastKey = AR_XXX;
                    lastRemoconType = RT_NONE;
                    idleCount = 0;
                }
                break;
            case IR_RECVING:

                break;
            case IR_RECVED:
                idleCount = 0;
                if (IrCtrl.fmt == SONY) {
                    // SONY BD $xx $2d $0f
                    // SONY TV $xx $20
                    if (IrCtrl.len >= 20 && IS_SONY_BD()) {
                        if (IrCtrl.rxdata[0] != lastKey)
                            lastKey = setKeyDown(IrCtrl.rxdata[0], SONY_BD);
                        lastRemoconType = SONY_BD;
                    } else if (IrCtrl.len >= 12 && IS_SONY_TV()) {
                        lastKey = setKeyDown(IrCtrl.rxdata[0], SONY_BD);
                        lastRemoconType = SONY_BD;
                    }
                }
                if (IrCtrl.fmt == NEC && IrCtrl.len >= 32) {
                    if (true || IS_APPLE_REMOTE()) {
                        lastKey = setKeyDown(IrCtrl.rxdata[2], APPLE_REMOTE);
                        lastRemoconType = APPLE_REMOTE;
                    }
                }
                if (lastRemoconType != SONY && IrCtrl.len == 0 && IrCtrl.fmt == (NEC | REPT) && lastKey != AR_XXX) {
                    //setKeyDown(lastKey, lastRemoconType);
                }
                IrCtrl.stat = IR_IDLE;
                break;
        }

    }
}
/**
 End of File
 */