/**
  @Generated Pin Manager Header File

  @Company:
    Microchip Technology Inc.

  @File Name:
    pin_manager.h

  @Summary:
    This is the Pin Manager file generated using PIC10 / PIC12 / PIC16 / PIC18 MCUs

  @Description
    This header file provides APIs for driver for .
    Generation Information :
        Product Revision  :  PIC10 / PIC12 / PIC16 / PIC18 MCUs - 1.65.2
        Device            :  PIC16F1705
        Driver Version    :  2.01
    The generated drivers are tested against the following:
        Compiler          :  XC8 1.45
        MPLAB 	          :  MPLAB X 4.15	
*/

/*
    (c) 2018 Microchip Technology Inc. and its subsidiaries. 
    
    Subject to your compliance with these terms, you may use Microchip software and any 
    derivatives exclusively with Microchip products. It is your responsibility to comply with third party 
    license terms applicable to your use of third party software (including open source software) that 
    may accompany Microchip software.
    
    THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER 
    EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS SOFTWARE, INCLUDING ANY 
    IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND FITNESS 
    FOR A PARTICULAR PURPOSE.
    
    IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND 
    WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF MICROCHIP 
    HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO 
    THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL 
    CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT EXCEED THE AMOUNT 
    OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS 
    SOFTWARE.
*/

#ifndef PIN_MANAGER_H
#define PIN_MANAGER_H

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set B14 aliases
#define B14_TRIS                 TRISAbits.TRISA2
#define B14_LAT                  LATAbits.LATA2
#define B14_PORT                 PORTAbits.RA2
#define B14_WPU                  WPUAbits.WPUA2
#define B14_OD                   ODCONAbits.ODA2
#define B14_ANS                  ANSELAbits.ANSA2
#define B14_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define B14_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define B14_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define B14_GetValue()           PORTAbits.RA2
#define B14_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define B14_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define B14_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define B14_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define B14_SetPushPull()        do { ODCONAbits.ODA2 = 0; } while(0)
#define B14_SetOpenDrain()       do { ODCONAbits.ODA2 = 1; } while(0)
#define B14_SetAnalogMode()      do { ANSELAbits.ANSA2 = 1; } while(0)
#define B14_SetDigitalMode()     do { ANSELAbits.ANSA2 = 0; } while(0)

// get/set k_left aliases
#define k_left_TRIS                 TRISAbits.TRISA4
#define k_left_LAT                  LATAbits.LATA4
#define k_left_PORT                 PORTAbits.RA4
#define k_left_WPU                  WPUAbits.WPUA4
#define k_left_OD                   ODCONAbits.ODA4
#define k_left_ANS                  ANSELAbits.ANSA4
#define k_left_SetHigh()            do { LATAbits.LATA4 = 1; } while(0)
#define k_left_SetLow()             do { LATAbits.LATA4 = 0; } while(0)
#define k_left_Toggle()             do { LATAbits.LATA4 = ~LATAbits.LATA4; } while(0)
#define k_left_GetValue()           PORTAbits.RA4
#define k_left_SetDigitalInput()    do { TRISAbits.TRISA4 = 1; } while(0)
#define k_left_SetDigitalOutput()   do { TRISAbits.TRISA4 = 0; } while(0)
#define k_left_SetPullup()          do { WPUAbits.WPUA4 = 1; } while(0)
#define k_left_ResetPullup()        do { WPUAbits.WPUA4 = 0; } while(0)
#define k_left_SetPushPull()        do { ODCONAbits.ODA4 = 0; } while(0)
#define k_left_SetOpenDrain()       do { ODCONAbits.ODA4 = 1; } while(0)
#define k_left_SetAnalogMode()      do { ANSELAbits.ANSA4 = 1; } while(0)
#define k_left_SetDigitalMode()     do { ANSELAbits.ANSA4 = 0; } while(0)

// get/set k_down aliases
#define k_down_TRIS                 TRISAbits.TRISA5
#define k_down_LAT                  LATAbits.LATA5
#define k_down_PORT                 PORTAbits.RA5
#define k_down_WPU                  WPUAbits.WPUA5
#define k_down_OD                   ODCONAbits.ODA5
#define k_down_SetHigh()            do { LATAbits.LATA5 = 1; } while(0)
#define k_down_SetLow()             do { LATAbits.LATA5 = 0; } while(0)
#define k_down_Toggle()             do { LATAbits.LATA5 = ~LATAbits.LATA5; } while(0)
#define k_down_GetValue()           PORTAbits.RA5
#define k_down_SetDigitalInput()    do { TRISAbits.TRISA5 = 1; } while(0)
#define k_down_SetDigitalOutput()   do { TRISAbits.TRISA5 = 0; } while(0)
#define k_down_SetPullup()          do { WPUAbits.WPUA5 = 1; } while(0)
#define k_down_ResetPullup()        do { WPUAbits.WPUA5 = 0; } while(0)
#define k_down_SetPushPull()        do { ODCONAbits.ODA5 = 0; } while(0)
#define k_down_SetOpenDrain()       do { ODCONAbits.ODA5 = 1; } while(0)

// get/set B15 aliases
#define B15_TRIS                 TRISCbits.TRISC0
#define B15_LAT                  LATCbits.LATC0
#define B15_PORT                 PORTCbits.RC0
#define B15_WPU                  WPUCbits.WPUC0
#define B15_OD                   ODCONCbits.ODC0
#define B15_ANS                  ANSELCbits.ANSC0
#define B15_SetHigh()            do { LATCbits.LATC0 = 1; } while(0)
#define B15_SetLow()             do { LATCbits.LATC0 = 0; } while(0)
#define B15_Toggle()             do { LATCbits.LATC0 = ~LATCbits.LATC0; } while(0)
#define B15_GetValue()           PORTCbits.RC0
#define B15_SetDigitalInput()    do { TRISCbits.TRISC0 = 1; } while(0)
#define B15_SetDigitalOutput()   do { TRISCbits.TRISC0 = 0; } while(0)
#define B15_SetPullup()          do { WPUCbits.WPUC0 = 1; } while(0)
#define B15_ResetPullup()        do { WPUCbits.WPUC0 = 0; } while(0)
#define B15_SetPushPull()        do { ODCONCbits.ODC0 = 0; } while(0)
#define B15_SetOpenDrain()       do { ODCONCbits.ODC0 = 1; } while(0)
#define B15_SetAnalogMode()      do { ANSELCbits.ANSC0 = 1; } while(0)
#define B15_SetDigitalMode()     do { ANSELCbits.ANSC0 = 0; } while(0)

// get/set k_up aliases
#define k_up_TRIS                 TRISCbits.TRISC1
#define k_up_LAT                  LATCbits.LATC1
#define k_up_PORT                 PORTCbits.RC1
#define k_up_WPU                  WPUCbits.WPUC1
#define k_up_OD                   ODCONCbits.ODC1
#define k_up_ANS                  ANSELCbits.ANSC1
#define k_up_SetHigh()            do { LATCbits.LATC1 = 1; } while(0)
#define k_up_SetLow()             do { LATCbits.LATC1 = 0; } while(0)
#define k_up_Toggle()             do { LATCbits.LATC1 = ~LATCbits.LATC1; } while(0)
#define k_up_GetValue()           PORTCbits.RC1
#define k_up_SetDigitalInput()    do { TRISCbits.TRISC1 = 1; } while(0)
#define k_up_SetDigitalOutput()   do { TRISCbits.TRISC1 = 0; } while(0)
#define k_up_SetPullup()          do { WPUCbits.WPUC1 = 1; } while(0)
#define k_up_ResetPullup()        do { WPUCbits.WPUC1 = 0; } while(0)
#define k_up_SetPushPull()        do { ODCONCbits.ODC1 = 0; } while(0)
#define k_up_SetOpenDrain()       do { ODCONCbits.ODC1 = 1; } while(0)
#define k_up_SetAnalogMode()      do { ANSELCbits.ANSC1 = 1; } while(0)
#define k_up_SetDigitalMode()     do { ANSELCbits.ANSC1 = 0; } while(0)

// get/set IR_RCV aliases
#define IR_RCV_TRIS                 TRISCbits.TRISC2
#define IR_RCV_LAT                  LATCbits.LATC2
#define IR_RCV_PORT                 PORTCbits.RC2
#define IR_RCV_WPU                  WPUCbits.WPUC2
#define IR_RCV_OD                   ODCONCbits.ODC2
#define IR_RCV_ANS                  ANSELCbits.ANSC2
#define IR_RCV_SetHigh()            do { LATCbits.LATC2 = 1; } while(0)
#define IR_RCV_SetLow()             do { LATCbits.LATC2 = 0; } while(0)
#define IR_RCV_Toggle()             do { LATCbits.LATC2 = ~LATCbits.LATC2; } while(0)
#define IR_RCV_GetValue()           PORTCbits.RC2
#define IR_RCV_SetDigitalInput()    do { TRISCbits.TRISC2 = 1; } while(0)
#define IR_RCV_SetDigitalOutput()   do { TRISCbits.TRISC2 = 0; } while(0)
#define IR_RCV_SetPullup()          do { WPUCbits.WPUC2 = 1; } while(0)
#define IR_RCV_ResetPullup()        do { WPUCbits.WPUC2 = 0; } while(0)
#define IR_RCV_SetPushPull()        do { ODCONCbits.ODC2 = 0; } while(0)
#define IR_RCV_SetOpenDrain()       do { ODCONCbits.ODC2 = 1; } while(0)
#define IR_RCV_SetAnalogMode()      do { ANSELCbits.ANSC2 = 1; } while(0)
#define IR_RCV_SetDigitalMode()     do { ANSELCbits.ANSC2 = 0; } while(0)

// get/set k_fire aliases
#define k_fire_TRIS                 TRISCbits.TRISC3
#define k_fire_LAT                  LATCbits.LATC3
#define k_fire_PORT                 PORTCbits.RC3
#define k_fire_WPU                  WPUCbits.WPUC3
#define k_fire_OD                   ODCONCbits.ODC3
#define k_fire_ANS                  ANSELCbits.ANSC3
#define k_fire_SetHigh()            do { LATCbits.LATC3 = 1; } while(0)
#define k_fire_SetLow()             do { LATCbits.LATC3 = 0; } while(0)
#define k_fire_Toggle()             do { LATCbits.LATC3 = ~LATCbits.LATC3; } while(0)
#define k_fire_GetValue()           PORTCbits.RC3
#define k_fire_SetDigitalInput()    do { TRISCbits.TRISC3 = 1; } while(0)
#define k_fire_SetDigitalOutput()   do { TRISCbits.TRISC3 = 0; } while(0)
#define k_fire_SetPullup()          do { WPUCbits.WPUC3 = 1; } while(0)
#define k_fire_ResetPullup()        do { WPUCbits.WPUC3 = 0; } while(0)
#define k_fire_SetPushPull()        do { ODCONCbits.ODC3 = 0; } while(0)
#define k_fire_SetOpenDrain()       do { ODCONCbits.ODC3 = 1; } while(0)
#define k_fire_SetAnalogMode()      do { ANSELCbits.ANSC3 = 1; } while(0)
#define k_fire_SetDigitalMode()     do { ANSELCbits.ANSC3 = 0; } while(0)

// get/set k_start aliases
#define k_start_TRIS                 TRISCbits.TRISC4
#define k_start_LAT                  LATCbits.LATC4
#define k_start_PORT                 PORTCbits.RC4
#define k_start_WPU                  WPUCbits.WPUC4
#define k_start_OD                   ODCONCbits.ODC4
#define k_start_ANS                  ANSELCbits.ANSC4
#define k_start_SetHigh()            do { LATCbits.LATC4 = 1; } while(0)
#define k_start_SetLow()             do { LATCbits.LATC4 = 0; } while(0)
#define k_start_Toggle()             do { LATCbits.LATC4 = ~LATCbits.LATC4; } while(0)
#define k_start_GetValue()           PORTCbits.RC4
#define k_start_SetDigitalInput()    do { TRISCbits.TRISC4 = 1; } while(0)
#define k_start_SetDigitalOutput()   do { TRISCbits.TRISC4 = 0; } while(0)
#define k_start_SetPullup()          do { WPUCbits.WPUC4 = 1; } while(0)
#define k_start_ResetPullup()        do { WPUCbits.WPUC4 = 0; } while(0)
#define k_start_SetPushPull()        do { ODCONCbits.ODC4 = 0; } while(0)
#define k_start_SetOpenDrain()       do { ODCONCbits.ODC4 = 1; } while(0)
#define k_start_SetAnalogMode()      do { ANSELCbits.ANSC4 = 1; } while(0)
#define k_start_SetDigitalMode()     do { ANSELCbits.ANSC4 = 0; } while(0)

// get/set k_right aliases
#define k_right_TRIS                 TRISCbits.TRISC5
#define k_right_LAT                  LATCbits.LATC5
#define k_right_PORT                 PORTCbits.RC5
#define k_right_WPU                  WPUCbits.WPUC5
#define k_right_OD                   ODCONCbits.ODC5
#define k_right_ANS                  ANSELCbits.ANSC5
#define k_right_SetHigh()            do { LATCbits.LATC5 = 1; } while(0)
#define k_right_SetLow()             do { LATCbits.LATC5 = 0; } while(0)
#define k_right_Toggle()             do { LATCbits.LATC5 = ~LATCbits.LATC5; } while(0)
#define k_right_GetValue()           PORTCbits.RC5
#define k_right_SetDigitalInput()    do { TRISCbits.TRISC5 = 1; } while(0)
#define k_right_SetDigitalOutput()   do { TRISCbits.TRISC5 = 0; } while(0)
#define k_right_SetPullup()          do { WPUCbits.WPUC5 = 1; } while(0)
#define k_right_ResetPullup()        do { WPUCbits.WPUC5 = 0; } while(0)
#define k_right_SetPushPull()        do { ODCONCbits.ODC5 = 0; } while(0)
#define k_right_SetOpenDrain()       do { ODCONCbits.ODC5 = 1; } while(0)
#define k_right_SetAnalogMode()      do { ANSELCbits.ANSC5 = 1; } while(0)
#define k_right_SetDigitalMode()     do { ANSELCbits.ANSC5 = 0; } while(0)

/**
   @Param
    none
   @Returns
    none
   @Description
    GPIO and peripheral I/O initialization
   @Example
    PIN_MANAGER_Initialize();
 */
void PIN_MANAGER_Initialize (void);

/**
 * @Param
    none
 * @Returns
    none
 * @Description
    Interrupt on Change Handling routine
 * @Example
    PIN_MANAGER_IOC();
 */
void PIN_MANAGER_IOC(void);



#endif // PIN_MANAGER_H
/**
 End of File
*/